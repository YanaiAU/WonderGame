﻿using UnityEngine;

/**
 * This is a static class that keeps the player scores between scenes.
 */
public class GAME_STATUS: MonoBehaviour {
    public static int playerScore = 0;
}
